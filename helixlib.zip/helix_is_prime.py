import ctypes
import time

try:
    lib = ctypes.CDLL('./asal_motoru.dll')
    lib.check_helical.argtypes = [ctypes.c_uint64]
    lib.check_helical.restype = ctypes.c_uint64
    lib.get_primes_count.restype = ctypes.c_size_t
    lib.init_motor()
except Exception as e:
    print(f"Hata: DLL yüklenemedi! {e}")
    exit()

print("--- C-DLL Motoru V4 (Opt) ---")

while True:
    try:
        n_input = input("\nSayı Gir (Çıkış: 0): ")
        if n_input == '0': break
        n = int(n_input)
        
        print("İşlem yapılıyor, lütfen bekleyin...")
        start_t = time.time()
        carpan = lib.check_helical(n)
        end_t = time.time()
        
        print("-" * 50)
        if carpan == 0:
            print(f"SONUÇ: {n} -> ASAL ✅")
        else:
            print(f"SONUÇ: {n} -> BİLEŞİK ❌ (Çarpan: {carpan})")
            
        print(f"SÜRE : {end_t - start_t:.8f} saniye")
        print(f"KAYITLI ASAL: {lib.get_primes_count()}")
        print("-" * 50)
        
    except ValueError:
        print("Geçerli bir sayı girin.")
    except KeyboardInterrupt:
        print("\nİşlem kullanıcı tarafından durduruldu.")
        break